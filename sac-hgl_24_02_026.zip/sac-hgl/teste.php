<?php
$conn = new pdo("mysql:host=localhost;dbname=lixo_supremo", "root", "");

// pegar especialidade selecionada
$especialidadeSelecionada = $_POST['especialidade'] ?? "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            max-width: 800px;
            width: 100%;
            overflow: hidden;
        }



        .form-container {
            padding: 40px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 0.95em;
        }

        input, select, textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
            transition: all 0.3s;
            font-family: inherit;
        }

        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .btn {
            background-color: #1863a8;
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        .btn:active {
            transform: translateY(0);
        }

        .success-message {
            display: none;
            background: #4caf50;
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }

        .error-message {
            display: none;
            background: #f44336;
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }

        .consultas-list {
            margin-top: 30px;
            padding-top: 30px;
            border-top: 2px solid #e0e0e0;
        }

        .consulta-item {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 4px solid #667eea;
        }

        .consulta-item h3 {
            color: #667eea;
            margin-bottom: 10px;
        }

        .consulta-info {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-top: 10px;
        }

        .info-item {
            font-size: 0.9em;
            color: #666;
        }

        .info-item strong {
            color: #333;
        }

        .btn-cancelar {
            background: #f44336;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            font-size: 0.9em;
        }

        .btn-cancelar:hover {
            background: #d32f2f;
        }

        @media (max-width: 768px) {
            .row, .consulta-info {
                grid-template-columns: 1fr;
            }

            .form-container {
                padding: 20px;
            }

            .header h1 {
                font-size: 1.5em;
            }
        }

        .required {
            color: #f44336;
        }
    </style>
</head>
<body>

<form method="POST">
    
    <!-- SELECT ESPECIALIDADE -->
    <label>Especialidade</label>
    <select name="especialidade" onchange="this.form.submit()">
        <option value="">Selecione</option>

        <?php
        $sql = $conn->query("SELECT * FROM tb_especialidade");
        while($esp = $sql->fetch()){
            $selected = ($esp['id'] == $especialidadeSelecionada) ? "selected" : "";
            echo "<option value='{$esp['id']}' $selected>{$esp['nome']}</option>";
        }
        ?>
    </select>


    <!-- SELECT MÉDICO -->
    <label>Médico</label>
    <select name="medico">
        <option value="">Selecione o médico</option>

        <?php
        if(!empty($especialidadeSelecionada)){
            $sqlMed = $conn->prepare("SELECT * FROM tb_medico WHERE especialidade_id = ?");
            $sqlMed->execute([$especialidadeSelecionada]);

            while($med = $sqlMed->fetch()){
                echo "<option value='{$med['id']}'>{$med['nome']}</option>";
            }
        }
        ?>
    </select>

</form>

</body>
</html>