<?php
   
include_once 'connection/conn.php';

try{
     $especialidadeSelecionada = $_GET['especialidade'] ?? "";

    if(!empty($especialidadeSelecionada)){
           
            $sqlMed = $conn->prepare("SELECT 
                    f.nome_completo,
                    f.cargo_id,
                    m.funcionario_id,
                    me.medico_id
                FROM tb_funcionario AS f
                LEFT JOIN tb_medico AS m
                ON m.funcionario_id = f.id
                LEFT JOIN tb_medico_especialidade AS me 
                ON me.medico_id = m.id 
                WHERE me.especialidade_id = ?;");
            $sqlMed->execute([$especialidadeSelecionada]);
        }
}catch(Exception $e){
    echo json_encode("Erro ao carregar médicos: " . $e->getMessage());
}
