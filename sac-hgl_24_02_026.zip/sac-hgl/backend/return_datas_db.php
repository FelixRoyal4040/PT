<?php
include_once 'connection/conn.php';

    try {

     if(isset($_GET['especialidade_id'])){
            $id_esp = $_GET['especialidade_id'];
                $sqlMed = $conn->prepare("SELECT 
                    f.nome_completo,
                    f.cargo_id,
                    m.funcionario_id,
                    me.medico_id
                FROM tb_funcionario AS f
                LEFT JOIN tb_medico AS m
                ON m.funcionario_id = f.id
                LEFT JOIN tb_medico_especialidade AS me 
                ON me.medico_id = m.id 
                WHERE me.especialidade_id = ?;");
            $sqlMed->execute([$id_esp]);

            $resp_medico = $sqlMed->fetchAll(PDO::FETCH_ASSOC); 

            echo json_encode([
                "medicos" => $resp_medico, 
                "status" => "ok"
            ]);
            exit();
        }
     
        $sql = $conn->prepare("SELECT id, nome FROM tb_especialidade");
        $sql->execute();
 
        $resp_especialidade = $sql->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
        "especialidades" => $resp_especialidade, 
        "status" => "ok"
        ]);
        exit();

        
}catch(Exception $e){
    echo json_encode([
        "status" => "error",
        "message" => "Erro ao carregar a resposta: " . $e->getMessage()
    ]);
}

?>