<?php
include_once 'connection/conn.php';

 try {
        $conn->beginTransaction();

 if(!empty($medicoselect)){
     $sqlhour = $conn->prepare("SELECT id, hora_inicio, hora_fim FROM tb_horario WHERE medico_id = ?");
    $sqlhour->execute([$medicoselect]);

    while($hour = $sqlhour->fetch()){
                    
    echo "<option value='{$hour['id']}'>{$hour['hora_inicio']}</option>";
     }
    }
}
catch(Exception $e){
    echo json_encode("Erro ao carregar horários: " . $e->getMessage());
}