<?php
    include_once 'connection/conn.php';

    header('Content-Type: application/json');
   

    try{
        $conn->beginTransaction();

        $nome_completo= $_POST['name'] ?? null;
        $data_nascimento= $_POST['data_nasc'] ?? null;
        $sexo= $_POST['gender'] ?? null;
        $telefone= $_POST['phone'] ?? null;
        $email= $_POST['email'] ?? null;
        $password= $_POST['password'] ?? null;

        $senhaHash = password_hash($password, PASSWORD_DEFAULT);

        $stmtUs = $conn->prepare("INSERT INTO tb_us (email, password) VALUES (?, ?)");
        $stmtUs->execute([$email, $senhaHash]);

        $us_id = $conn->lastInsertId();

        $stmtPaciente = $conn->prepare("INSERT INTO tb_paciente (us_id, nome_completo, data_nascimento, sexo, telefone) VALUES (?, ?, ?, ?, ?)");
        
        $stmtPaciente->execute([
            $us_id,
            $nome_completo,
            $data_nascimento,
            $sexo,
            $telefone
        ]);

        $conn->commit();
        echo json_encode([
            "success" => true,
            "message" => "Paciente cadastrado com sucesso!"
        ]);

    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode([
            "success" => false,
            "message" => "Erro ao cadastrar paciente: " . $e->getMessage()
        ]);
    }
?>
