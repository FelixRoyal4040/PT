<?php
include_once 'connection/conn.php';

    try {
        $conn->beginTransaction();

        $paciente = $_POST['name_pacient'];
        $contact = $_POST['phone'];
        $email = $_POST['email'];
        $type = $_POST['especialidade'];
        $medico = $_POST['medico'];
        $date_consult = $_POST['date_consult'];
        $horario_id  = $_POST['hour_disponible'];
        $observacoes = $_POST['observation'] ?? '';

        $check = $conn->prepare(
            "SELECT COUNT(*) FROM tb_consulta
             WHERE horario_id = ? AND status = 'Agendada'"
        );
        $check->execute([$horario_id]);

        if ($check->fetchColumn() > 0) {
            throw new Exception("Horário indisponível para este médico.");
        }


            $stmt = $conn->prepare(
            "INSERT INTO tb_consulta
             (horario_id, paciente_id, status, observacoes)
             VALUES (?, ?, 'Agendada', ?)"
        );
        $stmt->execute([
            $horario_id,
            $paciente,
            $observacoes
        ]);
      

        $conn->commit();
        echo json_encode(["message" => "Consulta agendada com sucesso!", "status" => "ok"]);

    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode("Erro ao agendar consulta: " . $e->getMessage());
    }
    
?>
