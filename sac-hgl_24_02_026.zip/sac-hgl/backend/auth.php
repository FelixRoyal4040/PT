<?php
  include_once 'connection/conn.php';
  session_start();

  header('Content-Type: application/json');

    try {
      
      $email = $_POST['email'];
      $password = $_POST['password'];

      $stmt = $conn->prepare("SELECT * FROM tb_us WHERE email = ?");
      $stmt->execute([$email]);
      $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
      if ($user && password_verify($password, $user['password'])) {

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];

        echo json_encode([
          "success" => true,
          "message" => "Login bem-sucedido"
        ]);
      } else {
        echo json_encode([
          "success" => false,
          "message" => "Email ou senha inválidos"
        ]);
      }

    } catch (Exception $e) {
      echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
      ]);
    }
  
?>