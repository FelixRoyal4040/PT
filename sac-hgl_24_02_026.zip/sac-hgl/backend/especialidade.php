<?php
include_once 'connection/conn.php';

    try {
        $conn->beginTransaction();

        $sql = $conn->query("SELECT id, nome FROM tb_especialidade");

        $conn->commit();
    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode("Erro ao carregar especialidades: " . $e->getMessage());
    }
    echo json_encode($sql->fetchAll(PDO::FETCH_ASSOC));
    echo json_encode($sqlMed->fetchAll(PDO::FETCH_ASSOC));
?>