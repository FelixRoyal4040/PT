
function link_cadastro(){
    window.location.href="cadastro.html"
}

form_login = document.querySelector("#formulario-card")
form_login.addEventListener("submit", event => send(event));

async function send(event) {
event.preventDefault()

  const form_login = event.target
    const form = new FormData(form_login)
try{

const response = await fetch("backend/auth.php",{
    method: 'POST',
    body: form
})
const response_server = await response.json()
console.log(response_server)

if(response_server.success === true){
    alert("Login realizado com sucesso")
    window.location.href="painel.php"
}
else{
    console.log("Falha no login: " + response_server.message)
}
}catch(error){
    console.log("erro de troca de dados com o exterior", error)
}
}


