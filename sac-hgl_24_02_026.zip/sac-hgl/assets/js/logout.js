   
document.querySelector("#btn_logout").addEventListener("click", async()=> {
const resposta = confirm("deseja fazer sair?")

if(resposta ){
    const response = await fetch("backend/logout.php", {
        method: 'POST',
    })
    const response_server = await response.json()
    if(response_server.status === "ok"){
        window.location.href="index.html"
    }
    else{
      alert("Erro ao terminar sessão")
    }
}
else{
    console.log("boa escolha")
}


})