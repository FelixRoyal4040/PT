function agendar_consulta(){
    window.location.href="agendar_consulta.html"
}