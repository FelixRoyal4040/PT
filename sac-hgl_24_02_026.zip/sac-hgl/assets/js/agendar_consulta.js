const form_agendamento = document.querySelector("#agendamentoForm");


const btn = document.querySelector("#teste_btn")
btn.addEventListener("click", ()=> {
    window.location.href="backend/return_datas_db.php"
})

const especialidade = document.querySelector("#especialidade");
const medico = document.querySelector("#medico");
const data = document.querySelector("#data");
const hora = document.querySelector("#horario");

async function load_especialidade(){

    const response_sr = await fetch("backend/return_datas_db.php")
    const data = await response_sr.json()
    const especialidades = data.especialidades
    console.log(especialidades)

    especialidade.innerHTML = '<option value="">Selecione</option>'

    especialidades.forEach(esp => {
        const option = document.createElement("option")
        option.value = esp.id
        option.textContent = esp.nome
        especialidade.appendChild(option)
    })
 
}

load_especialidade()

especialidade.addEventListener("change", async () => {
    const id_esp = especialidade.value 
    const response_sr = await fetch(`backend/return_datas_db.php?especialidade_id=${id_esp}`)
    const data_med = await response_sr.json()
    const medicos = data_med.medicos
    console.log(medicos)
    medico.innerHTML = '<option value="">Selecione o médico</option>'
    medicos.forEach(med => {
        const option = document.createElement("option") 
        option.value = med.medico_id
        option.textContent = med.nome_completo
        medico.appendChild(option)
    })
})



form_agendamento.addEventListener("submit", event => send(event));

async function send(event){
    event.preventDefault()
    try{
        const form_agendamento = event.target
        const form = new FormData(form_agendamento)

        const response = await fetch("backend/agendamento.php",{
            method: "POST",
            body: form  
        }) 
        const response_server = await response.json()
        console.log(response_server)
        
     if(response_server.status === "ok"){
             window.location.href = "../../painel.html" 
        }
        else{
            console.log("Erro no agendamento")
        }
        
    }catch(error){
        console.log("Erro ao enviar o formulário:", error)
    }   
     
}