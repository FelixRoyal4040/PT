

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            max-width: 800px;
            width: 100%;
            overflow: hidden;
        }



        .form-container {
            padding: 40px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 0.95em;
        }

        input, select, textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
            transition: all 0.3s;
            font-family: inherit;
        }

        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .btn {
            background-color: #1863a8;
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        .btn:active {
            transform: translateY(0);
        }

        .success-message {
            display: none;
            background: #4caf50;
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }

        .error-message {
            display: none;
            background: #f44336;
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }

        .consultas-list {
            margin-top: 30px;
            padding-top: 30px;
            border-top: 2px solid #e0e0e0;
        }

        .consulta-item {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 4px solid #667eea;
        }

        .consulta-item h3 {
            color: #667eea;
            margin-bottom: 10px;
        }

        .consulta-info {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-top: 10px;
        }

        .info-item {
            font-size: 0.9em;
            color: #666;
        }

        .info-item strong {
            color: #333;
        }

        .btn-cancelar {
            background: #f44336;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            font-size: 0.9em;
        }

        .btn-cancelar:hover {
            background: #d32f2f;
        }

        @media (max-width: 768px) {
            .row, .consulta-info {
                grid-template-columns: 1fr;
            }

            .form-container {
                padding: 20px;
            }

            .header h1 {
                font-size: 1.5em;
            }
        }

        .required {
            color: #f44336;
        }
    </style>
</head>
<body>
    <button id="teste_btn">PHP</button>
    <div class="container">

        <div class="form-container">
            <div class="success-message" id="successMessage">
                ✓ Consulta agendada com sucesso!
            </div>
            <div class="error-message" id="errorMessage">
                ✗ Por favor, preencha todos os campos obrigatórios.
            </div>

            <form id="agendamentoForm">
                <h2 style="margin-bottom: 25px; color: #333;">Agendar Nova Consulta</h2>

                <div class="form-group">
                    <label>Nome Completo <span class="required">*</span></label>
                    <input type="text" id="nome" required name="name_pacient" placeholder="Digite seu nome completo">
                </div>

                <div class="row">
                    <div class="form-group">
                        <label>Contacto <span class="required">*</span></label>
                        <input type="tel" name="phone" id="contacto" required placeholder="Ex: 923456789">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" id="email" placeholder="seu@email.com">
                    </div>
                </div>

                <div class="row">
                    <div class="form-group">

                 <label>Especialidade</label>
                 <select id="especialidade" name="especialidade">
            <option value="">Selecione</option>
    
    
    </select>

                    </div>
                    <div class="form-group">
                     
                     <label>Médico</label>
            <select id="medico" name="medico">
        <option value="">Selecione o médico</option>
 

    </select>
                    </div>
                </div>

                <div class="row">
                    <div class="form-group">
                        <label>Data da Consulta <span class="required">*</span></label>
                        <input type="date" name="date_consult" id="data" required>
                    </div>
                    <div class="form-group">
                        <label>Horário Disponível <span class="required">*</span></label>
                        <select id="horario" name="hour_disponible" required>
                            <option value="">Selecione o horario disponivel</option>
  
                        </select>
                        
                    </div>
                </div>

                <div class="form-group">
                    <label>Observações</label>
                    <textarea id="observacoes" name="observation" rows="4" placeholder="Descreva seus sintomas ou motivo da consulta..."></textarea>
                </div>

                <button type="submit" class="btn">Agendar Consulta</button>
            </form>

        </div>
    </div>
       
 
    
</body>
</html>

<script src="assets/js/agendar_consulta.js"></script>