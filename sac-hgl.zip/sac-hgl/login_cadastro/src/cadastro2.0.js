mostrar_form = document.querySelector("#step2")
desaparecer = document.querySelector("#step1")

function handleNext(){
    desaparecer.style.display="none"
    mostrar_form.style.display="flex"
}

function goToLogin(){
    window.location.href="../../../../tcc/Medilab/login_cadastro/login.html"
}


const formulario = document.getElementById("form_sac_hgl");

formulario.addEventListener("submit", event => send(event));

async function send(event){
    event.preventDefault()
    try{
        const formulario = event.target
        const form = new FormData(formulario)

        const response = await fetch("../backend/cadastro.php",{
            method: "POST",
            body: form
        }) 
        const response_server = await response.json()
        console.log(response_server)
        
        if(response_server.status === "success"){
            alert(response_server.message);
            window.location.href="../../../../tcc/Medilab/login_cadastro/login.html"
        }
        else if(response_server.status === "error"){
            alert(response_server.message);
            
        }
        
    }catch(error){
        console.error("Erro ao enviar o formulário:", error)
    }    
}