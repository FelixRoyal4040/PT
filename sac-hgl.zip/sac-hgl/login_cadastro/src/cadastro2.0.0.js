mostrar_form = document.querySelector("#step2")
desaparecer = document.querySelector("#step1")

function handleNext(){
    desaparecer.style.display="none"
    mostrar_form.style.display="flex"
}

function goToLogin(){
    window.location.href="../login.html"
}

alert("Funcionou!")
const formulario = document.getElementById("form_sac_hgl");

function send(e){
    e.preventDefault()

        const form = new FormData(formulario)

        fetch("../../backend/cadastro.php",{
            method: "POST",
            body: form
        })
        .then(res=>res.json())
        .then(data=>{
            if(data.success){
                alert(data.message);
            }
        })
        .catch(error=>{
            console.error("Erro: ", error)
        } )   
}