
function link_cadastro(){
    window.location.href="../../../../tcc/Medilab/login_cadastro/cadastro.html"
}




form_login = document.querySelector("#formulario-card")
form_login.addEventListener("submit", event => send(event));

async function send(event) {
event.preventDefault()

  const form_login = event.target
    const form = new FormData(form_login)
try{

const response = await fetch("../../../../tcc/Medilab/backend/login.php",{
    method: 'POST',
    body: form
})
const response_server = await response.json()
console.log(response_server)

if(response_server.status === "ok"){
console.log("Login realizado com sucesso")
window.location.href="../../../../tcc/Medilab/painel_paciente/painel.html"
}
else{
    console.log("erro ao se comunicar com o servidor")
}
}catch(error){
    console.log("erro de troca de dados com o exterior", error)
}
}


