const form_agendamento = document.querySelector("#agendamentoForm");

form_agendamento.addEventListener("submit", event => send(event));

async function send(event){
    event.preventDefault()
    try{
        const form_agendamento = event.target
        const form = new FormData(form_agendamento)

        const response = await fetch("back/agendar_consulta.php",{
            method: "POST",
            body: form
        }) 
        const response_server = await response.json()
        console.log(response_server)
        
     if(response_server.status === "ok"){
             window.location.href = "painel.html" 
        }
        else{
            console.log("Erro no agendamento")
        }
        
    }catch(error){
        console.log("Erro ao enviar o formulário:", error)
    }   
     
}