const name_user = window.prompt("Digite seu nome")
const age_user = window.prompt("Digite a sua idade")

let activeTab = 'overview';
let patientData = null;
let upcomingAppointments = [];
let pastAppointments = [];
let medications = [];
let exams = [];
let healthMetrics = null;
let notifications = [];



function loadMockData() {
  patientData = {
    name: name_user,
    age: age_user,
  };


  upcomingAppointments = [
    {
      id: '1',
      specialty: 'Cardiologia',
      doctor: 'Dr. Carlos Mendes',
      date: '2025-01-15',
      time: '14:30',
    },
    {
      id: '2',
      specialty: 'Dermatologia',
      doctor: 'Dra. Ana Cardoso',
      date: '2025-01-20',
      time: '10:00',
    },
    {
      id: '3',
      specialty: 'Oftalmologia',
      doctor: 'Dr. Ricardo Santos',
      date: '2025-02-05',
      time: '16:00',
    }
  ];

  
  pastAppointments = [
    {
      id: '4',
      specialty: 'Clínico Geral',
      doctor: 'Dr. Pedro Oliveira',
      date: '2024-12-10',
      time: '09:00'
    },
    {
      id: '5',
      specialty: 'Ortopedia',
      doctor: 'Dr. Lucas Ferreira',
      date: '2024-11-25',
      time: '15:30'
    }
  ];

 
  medications = [
    {
      id: '1',
      name: 'Losartana 50mg',
      dosage: '50mg',
      frequency: '1x ao dia',
      stock: 45,
      times: ['08:00']
    },
    {
      id: '2',
      name: 'Metformina 850mg',
      dosage: '850mg',
      frequency: '2x ao dia',
      stock: 15,
      times: ['08:00', '20:00']
    },
    {
      id: '3',
      name: 'Omeprazol 20mg',
      dosage: '20mg',
      frequency: '1x ao dia',
      stock: 60,
      times: ['07:00']
    },
    {
      id: '4',
      name: 'Sinvastatina 40mg',
      dosage: '40mg',
      frequency: '1x ao dia',
      stock: 8,
      times: ['22:00']
    }
  ];


  exams = [
    {
      id: '1',
      name: 'Hemograma Completo',
      doctor: 'Dr. Pedro Oliveira',
      date: '2024-12-15'
    },
    {
      id: '2',
      name: 'Raio-X de Tórax',
      doctor: 'Dr. Lucas Ferreira',
      date: '2024-11-28'
    },
    {
      id: '3',
      name: 'Ultrassom Abdominal',
      doctor: 'Dr. Carlos Mendes',
      date: '2024-10-20'
    },
    {
      id: '4',
      name: 'Eletrocardiograma',
      doctor: 'Dr. Carlos Mendes',
      date: '2024-09-10'
    }
  ];


  healthMetrics = {
    heartRate: 72,
    bloodPressure: '120/80',
    weight: 78,
    height: 175,
    bmi: '25.5'
  };

 
  notifications = [
    {
      id: '1',
      message: 'Consulta com Dr. Carlos Mendes amanhã às 14:30',
      time: 'Há 2 horas'
    },
    {
      id: '2',
      message: 'Seu estoque de Sinvastatina está baixo',
      time: 'Há 5 horas'
    },
    {
      id: '3',
      message: 'Resultado do exame de hemograma disponível',
      time: 'Há 1 dia'
    }
  ];
}


async function fetchWithAuth(url, options = {}) {
  console.log('API call seria feita para:', url);
  return null;
}

async function loadPatientProfile() {
  console.log('Carregando perfil do paciente');
}

async function loadAppointments() {
  console.log('Carregando consultas');
  
}


async function loadMedications() {
  console.log('Carregando medicamentos');
  
}

async function loadExams() {
  console.log('Carregando exames');
}

async function loadHealthMetrics() {
  console.log('Carregando métricas de saúde');
}

async function loadNotifications() {
  console.log('Carregando notificações');
  
}

async function loadAllData() {
  try {

    loadMockData();
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    await Promise.all([
      loadPatientProfile(),
      loadAppointments(),
      loadMedications(),
      loadExams(),
      loadHealthMetrics(),
      loadNotifications()
    ]);
    
    updateUI();
    renderContent();
    renderSidebar();
    
    document.getElementById('loadingScreen').classList.add('hidden');
    document.getElementById('mainApp').classList.remove('hidden');
    lucide.createIcons();
  } catch (err) {
    console.error('Erro ao carregar dados:', err);
    alert('Erro ao carregar dados. Tente novamente.');
  }
}

function updateUI() {
  if (patientData) {
    const initials = patientData.name?.split(' ').map(n => n[0]).join('').slice(0, 2) || 'PA';
    document.getElementById('avatar').textContent = initials;
    document.getElementById('welcomeText').textContent = `Olá, ${patientData.name || 'Paciente'}!`;
  }

  if (upcomingAppointments.length > 0) {
    const date = new Date(upcomingAppointments[0].date);
    document.getElementById('nextAppointment').textContent = 
      date.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
  }

  if (healthMetrics) {
    document.getElementById('heartRate').textContent = `${healthMetrics.heartRate || '--'} bpm`;
    document.getElementById('bloodPressure').textContent = healthMetrics.bloodPressure || '--';
  }

  
  document.getElementById('medicationCount').textContent = medications.length;

  if (notifications.length > 0) {
    const badge = document.getElementById('notificationBadge');
    badge.textContent = notifications.length;
    badge.classList.remove('hidden');
  }
}

function switchTab(tab) {
  activeTab = tab;
  
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
  
  renderContent();
  lucide.createIcons();
}

function renderContent() {
  const content = document.getElementById('mainContent');
  
  switch(activeTab) {
    case 'overview':
      renderOverview(content);
      break;
    case 'appointments':
      renderAppointments(content);
      break;
    case 'medications':
      renderMedications(content);
      break;
    case 'exams':
      renderExams(content);
      break;
  }
}

function renderOverview(container) {
  container.innerHTML = `
    <!-- Próximas Consultas -->
    <div class="card">
      <h2 class="card-title">
        <i data-lucide="calendar"></i>
        Próximas Consultas
      </h2>
      ${upcomingAppointments.length > 0 ? 
        upcomingAppointments.slice(0, 2).map(apt => `
          <div class="item-card">
            <div class="item-header">
              <div>
                <h3 class="item-title">${apt.specialty}</h3>
                <p class="item-subtitle">${apt.doctor}</p>
                <div class="item-info">
                  <i data-lucide="clock"></i>
                  ${new Date(apt.date).toLocaleDateString('pt-BR')} às ${apt.time}
                </div>
                ${apt.location ? `<p style="font-size: 0.75rem; color: #9ca3af; margin-top: 0.25rem;">${apt.location}</p>` : ''}
              </div>
              <span class="badge badge-green">Confirmado</span>
            </div>
          </div>
        `).join('') 
        : 
        '<p class="empty-state">Você não tem consultas agendadas</p>'
      }
      <button class="btn-primary" style="margin-top: 1rem;">Agendar Nova Consulta</button>
    </div>

    <!-- Medicamentos em Uso -->
    <div class="card">
      <h2 class="card-title">
        <i data-lucide="pill"></i>
        Medicamentos em Uso
      </h2>
      ${medications.length > 0 ? 
        medications.slice(0, 2).map(med => `
          <div class="item-card">
            <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
              <div>
                <h3 class="item-title">${med.name}</h3>
                <p class="item-subtitle">${med.dosage} - ${med.frequency}</p>
              </div>
              <span class="badge ${med.stock < 20 ? 'badge-red' : 'badge-green'}">${med.stock} und.</span>
            </div>
            ${med.times ? `
              <div class="tag-group">
                ${med.times.map(t => `<span class="tag">${t}</span>`).join('')}
              </div>
            ` : ''}
          </div>
        `).join('') 
        : 
        '<p class="empty-state">Nenhum medicamento cadastrado</p>'
      }
    </div>
  `;
}

function renderAppointments(container) {
  container.innerHTML = `
    <div class="card">
      <h2 class="card-title">Minhas Consultas</h2>
      
      <!-- Próximas -->
      <h3 class="section-title">Próximas</h3>
      ${upcomingAppointments.length > 0 ? 
        upcomingAppointments.map(apt => `
          <div class="item-card">
            <div style="display: flex; justify-content: space-between; align-items: start;">
              <div>
                <h4 class="item-title">${apt.specialty}</h4>
                <p class="item-subtitle">${apt.doctor}</p>
                <p class="item-info" style="margin-top: 0.25rem;">
                  ${new Date(apt.date).toLocaleDateString('pt-BR')} às ${apt.time}
                </p>
                ${apt.location ? `<p style="font-size: 0.75rem; color: #9ca3af;">${apt.location}</p>` : ''}
              </div>
              <div class="action-buttons">
                <button class="btn-link">Reagendar</button>
                <button class="btn-link danger" onclick="handleCancelAppointment('${apt.id}')">Cancelar</button>
              </div>
            </div>
          </div>
        `).join('') 
        : 
        '<p class="empty-state" style="padding: 1rem;">Nenhuma consulta agendada</p>'
      }

      <!-- Histórico -->
      <h3 class="section-title">Histórico</h3>
      ${pastAppointments.length > 0 ? 
        pastAppointments.map(apt => `
          <div class="item-card" style="background: #f9fafb;">
            <div style="display: flex; justify-content: space-between; align-items: start;">
              <div>
                <h4 class="item-title">${apt.specialty}</h4>
                <p class="item-subtitle">${apt.doctor}</p>
                <p class="item-info" style="margin-top: 0.25rem;">
                  ${new Date(apt.date).toLocaleDateString('pt-BR')} às ${apt.time}
                </p>
              </div>
              <i data-lucide="check-circle" style="color: #16a34a; width: 20px; height: 20px;"></i>
            </div>
          </div>
        `).join('') 
        : 
        '<p class="empty-state" style="padding: 1rem;">Nenhuma consulta no histórico</p>'
      }
    </div>
  `;
}

function renderMedications(container) {
  container.innerHTML = `
    <div class="card">
      <h2 class="card-title">Meus Medicamentos</h2>
      ${medications.length > 0 ? 
        medications.map(med => `
          <div class="item-card">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.75rem;">
              <div>
                <h3 style="font-weight: 600; color: #1f2937; font-size: 1.125rem; margin-bottom: 0.25rem;">${med.name}</h3>
                <p class="item-subtitle">${med.dosage}</p>
                <p class="item-info" style="margin-top: 0.25rem;">${med.frequency}</p>
              </div>
              <div class="stock-indicator">
                <p class="stock-label">Estoque</p>
                <p class="stock-value ${med.stock < 20 ? 'low' : 'good'}">${med.stock}</p>
              </div>
            </div>
            ${med.times ? `
              <div style="margin-bottom: 0.75rem;">
                ${med.times.map(t => `<span class="med-time">${t}</span>`).join('')}
              </div>
            ` : ''}
            ${med.stock < 20 ? `
              <div class="alert">
                <i data-lucide="alert-circle"></i>
                Estoque baixo - renovar receita
              </div>
            ` : ''}
          </div>
        `).join('') 
        : 
        '<p class="empty-state">Nenhum medicamento cadastrado</p>'
      }
    </div>
  `;
}

function renderExams(container) {
  container.innerHTML = `
    <div class="card">
      <h2 class="card-title">Meus Exames</h2>
      ${exams.length > 0 ? 
        exams.map(exam => `
          <div class="item-card">
            <div style="display: flex; justify-content: space-between; align-items: start;">
              <div style="flex: 1;">
                <h3 class="item-title">${exam.name}</h3>
                <p class="item-subtitle">Solicitado por: ${exam.doctor}</p>
                <p class="item-info" style="margin-top: 0.25rem;">
                  Data: ${new Date(exam.date).toLocaleDateString('pt-BR')}
                </p>
              </div>
              <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 0.5rem;">
                <span class="badge badge-green">Disponível</span>
                <button class="btn-link" onclick="handleDownloadExam('${exam.id}')">
                  <i data-lucide="download" style="width: 14px; height: 14px; margin-right: 0.25rem;"></i>
                  Baixar
                </button>
              </div>
            </div>
          </div>
        `).join('') 
        : 
        '<p class="empty-state">Nenhum exame disponível</p>'
      }
    </div>
  `;
}

function renderSidebar() {
  const sidebar = document.getElementById('sidebarContent');
  
  sidebar.innerHTML = `
    <!-- Perfil -->
    <div class="card">
      <h3 class="card-title" style="font-size: 1rem;">
        <i data-lucide="user"></i>
        Meu Perfil
      </h3>
      <div style="font-size: 0.875rem;">
        <div class="profile-item">
          <p class="profile-label">Idade</p>
          <p class="profile-value">${patientData?.age || '--'} anos</p>
        </div>
        <div class="profile-item">
          <p class="profile-label">Tipo Sanguíneo</p>
          <p class="profile-value">${patientData?.bloodType || 'Não informado'}</p>
        </div>
        ${healthMetrics ? `
          <div class="profile-item">
            <p class="profile-label">Peso</p>
            <p class="profile-value">${healthMetrics.weight} kg</p>
          </div>
          <div class="profile-item">
            <p class="profile-label">Altura</p>
            <p class="profile-value">${healthMetrics.height} cm</p>
          </div>
          <div class="profile-item">
            <p class="profile-label">IMC</p>
            <p class="profile-value">${healthMetrics.bmi}</p>
          </div>
        ` : ''}
      </div>
      <button class="btn-secondary" style="margin-top: 1rem;">Editar Perfil</button>
    </div>

    <!-- Notificações -->
    <div class="card">
      <h3 class="card-title" style="font-size: 1rem;">
        <i data-lucide="bell"></i>
        Notificações
      </h3>
      ${notifications.length > 0 ? 
        notifications.map(notif => `
          <div class="notification-item">
            <p class="notification-message">${notif.message}</p>
            <p class="notification-time">${notif.time}</p>
          </div>
        `).join('') 
        : 
        '<p style="color: #6b7280; font-size: 0.875rem;">Nenhuma notificação</p>'
      }
    </div>

    <!-- Suporte -->
    <div class="support-card">
      <i data-lucide="message-square"></i>
      <h3 class="support-title">Precisa de Ajuda?</h3>
      <p class="support-text">Nossa equipe está pronta para atendê-lo</p>
      <button class="support-btn">Falar com Suporte</button>
    </div>
  `;
}

async function handleCancelAppointment(appointmentId) {
  if (!confirm('Tem certeza que deseja cancelar esta consulta?')) {
    return;
  }

  upcomingAppointments = upcomingAppointments.filter(apt => apt.id !== appointmentId);
  alert('Consulta cancelada com sucesso!');
  updateUI();
  renderContent();
  lucide.createIcons();
}


function handleLogout() {
  if (confirm('Deseja realmente sair?')) {
    localStorage.removeItem('token');
    localStorage.removeItem('userType');
    localStorage.removeItem('userId');
    localStorage.removeItem('userName');
    alert('Logout realizado com sucesso!');
    window.location.href = '../login_cadastro/login.html';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  console.log('=== PAINEL DO PACIENTE ===');
  console.log('Modo: DADOS ESTÁTICOS (Mock)');
  console.log('Para usar dados reais, descomente as seções marcadas no código');
  loadAllData();
});