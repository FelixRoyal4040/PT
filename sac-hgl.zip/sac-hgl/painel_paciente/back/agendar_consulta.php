<?php

$conexao = new PDO("mysql:host=localhost;dbname=db_sac_hgl","root","");

$name = $_POST['name_pacient'] ?? null;
$phone = $_POST['phone'] ?? null;
$email = $_POST['email'] ?? null;
$type_consult = $_POST['type_consult'] ?? null;
$medico = $_POST['medico'] ?? null;
$date_consult = $_POST['date_consult'] ?? null;
$hour_disponible = $_POST['hour_disponible'] ?? null;
$observation = $_POST['observation'] ?? null;


$insert = "INSERT INTO agendamento_consulta (name_pacient, phone, email, type_consult, medico, date_consult, hour_disponible, observation) VALUES (?,?,?,?,?,?,?,?)";

$stmt_terminal = $conexao->prepare($insert);
$consult = $stmt_terminal->execute([$name, $phone, $email, $type_consult, $medico, $date_consult, $hour_disponible, $observation]);

if($consult){
    echo json_encode(["status" => "ok", "message" => "Agendamento feito com sucesso"]);
} else {
    echo json_encode("erro ao realizar cadastro");
}
?>