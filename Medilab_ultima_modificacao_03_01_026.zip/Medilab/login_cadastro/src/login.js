        let userType = 'patient';
        let loading = false;

        document.querySelectorAll('.user-type-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.user-type-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                userType = this.dataset.type;
            });
        });
        function showError(message) {
            const errorDiv = document.getElementById('errorMessage');
            const errorText = document.getElementById('errorText');
            errorText.textContent = message;
            errorDiv.classList.add('show');
        }

        function hideError() {
            document.getElementById('errorMessage').classList.remove('show');
        }
        document.getElementById('email').addEventListener('input', hideError);
        document.getElementById('password').addEventListener('input', hideError);

        async function handleLogin(e) {
            e.preventDefault();
            
            if (loading) return;

            hideError();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            if (!email || !password) {
                showError('Preencha todos os campos');
                return;
            }

            loading = true;
            const loginBtn = document.getElementById('loginBtn');
            loginBtn.disabled = true;
            loginBtn.innerHTML = '<div class="spinner"></div> Entrando...';

            try {
                const response = await fetch('https://sua-api.com/api/auth/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        email: email,
                        password: password,
                        userType: userType
                    })
                });

                const data = await response.json();

                if (!response.ok) {
                    throw new Error(data.message || 'Erro ao fazer login');
                }
                const userData = {
                    token: data.token,
                    userType: data.userType,
                    userId: data.userId,
                    userName: data.userName
                };

                if (data.userType === 'admin') {
                    window.location.href = '../painel_admin';
                } else {
                    window.location.href = '../painel_paciente/painel.html';
                }
            } catch (err) {
                showError(err.message || 'Erro ao fazer login. Tente novamente.');
            } finally {
                loading = false;
                loginBtn.disabled = false;
                loginBtn.innerHTML = 'Entrar';
            }
        }

        document.getElementById('loginForm').addEventListener('submit', handleLogin);

        document.getElementById('signupBtn').addEventListener('click', () => {
            window.location.href = "./cadastro.html"
        });
