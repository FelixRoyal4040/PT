        let currentStep = 1;
        let loading = false;

        const formData = {
            name: '',
            email: '',
            password: '',
            confirmPassword: '',
            phone: '',
            birthDate: '',
            bloodType: '',
            gender: ''
        };

        document.querySelectorAll('input, select').forEach(input => {
            input.addEventListener('input', function() {
                const fieldName = this.id;
                clearError(fieldName);
                formData[fieldName] = this.value;
            });
        });
        document.querySelectorAll('input[name="gender"]').forEach(radio => {
            radio.addEventListener('change', function() {
                formData.gender = this.value;
                clearError('gender');
            });
        });

        document.getElementById('birthDate').max = new Date().toISOString().split('T')[0];

        function clearError(field) {
            const errorElement = document.getElementById(field + 'Error');
            const inputElement = document.getElementById(field);
            
            if (errorElement) {
                errorElement.textContent = '';
            }
            if (inputElement) {
                inputElement.classList.remove('error');
            }
        }

        function showError(field, message) {
            const errorElement = document.getElementById(field + 'Error');
            const inputElement = document.getElementById(field);
            
            if (errorElement) {
                errorElement.textContent = message;
            }
            if (inputElement) {
                inputElement.classList.add('error');
            }
        }

        function showGeneralError(message) {
            document.getElementById('generalErrorText').textContent = message;
            document.getElementById('generalError').classList.add('show');
        }

        function hideGeneralError() {
            document.getElementById('generalError').classList.remove('show');
        }

        function validateStep1() {
            let isValid = true;
            hideGeneralError();

            formData.name = document.getElementById('name').value;
            formData.email = document.getElementById('email').value;
            formData.password = document.getElementById('password').value;
            formData.confirmPassword = document.getElementById('confirmPassword').value;

            if (!formData.name || formData.name.length < 3) {
                showError('name', 'Nome deve ter pelo menos 3 caracteres');
                isValid = false;
            }

            if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) {
                showError('email', 'E-mail inválido');
                isValid = false;
            }

            if (!formData.password || formData.password.length < 6) {
                showError('password', 'Senha deve ter pelo menos 6 caracteres');
                isValid = false;
            }

            if (formData.password !== formData.confirmPassword) {
                showError('confirmPassword', 'As senhas não coincidem');
                isValid = false;
            }

            return isValid;
        }

        function validateStep2() {
            let isValid = true;
            hideGeneralError();

            formData.phone = document.getElementById('phone').value;
            formData.birthDate = document.getElementById('birthDate').value;
            formData.bloodType = document.getElementById('bloodType').value;

            if (!formData.phone) {
                showError('phone', 'Telefone é obrigatório');
                isValid = false;
            }

            if (!formData.birthDate) {
                showError('birthDate', 'Data de nascimento é obrigatória');
                isValid = false;
            }

            if (!formData.gender) {
                showError('gender', 'Selecione o sexo');
                isValid = false;
            }

            return isValid;
        }

        function handleNext() {
            if (validateStep1()) {
                currentStep = 2;
                document.getElementById('step1').classList.remove('active');
                document.getElementById('step2').classList.add('active');
                document.getElementById('step2Indicator').classList.add('active');
                document.getElementById('progressLine').classList.add('active');
            }
        }

        function goBackToStep1() {
            currentStep = 1;
            document.getElementById('step2').classList.remove('active');
            document.getElementById('step1').classList.add('active');
            document.getElementById('step2Indicator').classList.remove('active');
            document.getElementById('progressLine').classList.remove('active');
        }

        async function handleRegister() {
            if (!validateStep2()) {
                return;
            }

            if (loading) return;

            loading = true;
            hideGeneralError();

            const registerBtn = document.getElementById('registerBtn');
            const backBtn = document.getElementById('backBtn');
            
            registerBtn.disabled = true;
            backBtn.disabled = true;
            registerBtn.innerHTML = '<div class="spinner"></div> Criando...';

            try {
                const response = await fetch('https://sua-api.com/api/auth/register', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        name: formData.name,
                        email: formData.email,
                        password: formData.password,
                        phone: formData.phone,
                        birthDate: formData.birthDate,
                        bloodType: formData.bloodType,
                        gender: formData.gender
                    })
                });

                const data = await response.json();

                if (!response.ok) {
                    throw new Error(data.message || 'Erro ao criar conta');
                }

                showSuccessScreen();

                setTimeout(() => {
                 window.location.href = './login.html';
                }, 2000);

            } catch (err) {
                showGeneralError(err.message || 'Erro ao criar conta. Tente novamente.');
            } finally {
                loading = false;
                registerBtn.disabled = false;
                backBtn.disabled = false;
                registerBtn.innerHTML = 'Criar Conta';
            }
        }

        function showSuccessScreen() {
            document.body.classList.add('success-screen');
            document.getElementById('mainContent').style.display = 'none';
            document.getElementById('successScreen').style.display = 'flex';
        }

        function goToLogin() {
            window.location.href = "./login.html"
        }