<?php
	include_once 'connection/conn.php';
	header('Content-Type: application/json');

	try {
		$conn->beginTransaction();

		$nome_completo= $_POST['name'] ?? null;
		$speciality= $_POST['speciality'] ?? null;
		$cargo= $_POST['cargo'] ?? null;
		$email= $_POST['email'] ?? null;
		$password= $_POST['password'] ?? null;	
		$phone= $_POST['phone'] ?? null;
		$hora_inicio = $_POST['hora_consult'] ?? null;
		$data_consult = '2024-06-01';
		$hora_fim = '12:00:00';

		$search = $conn->prepare("SELECT id FROM tb_especialidade WHERE nome = ?");
		$search->execute([$speciality]);
		$especialidade = $search->fetch(PDO::FETCH_ASSOC);
        /*
		if (!$especialidade) {
				throw new Exception("Especialidade não encontrada");
		}*/

		if (empty($cargo)) {
    throw new Exception("Cargo é obrigatório");
}

$searchCargo = $conn->prepare("SELECT id FROM tb_cargo WHERE id = ?");
$searchCargo->execute([$cargo]);
$cargoData = $searchCargo->fetch(PDO::FETCH_ASSOC);

if (!$cargoData) {
    throw new Exception("Cargo inválido");
}

$cargo_id = $cargoData['id'];


		$speciality_id = $especialidade['id'];

		$senha_padrao = password_hash($password, PASSWORD_DEFAULT);

		$insert = $conn->prepare("INSERT INTO tb_us (email, password) VALUES (?, ?)");
		$insert->execute([$email, $senha_padrao]);

		$us_id = $conn->lastInsertId();

		$insert = $conn->prepare("INSERT INTO tb_funcionario (us_id, nome_completo,  cargo_id, phone) VALUES (?, ?, ?, ?)");
		$insert->execute([$us_id, $nome_completo, $cargo_id,$phone]);

		$funcionario_id = $conn->lastInsertId();

		$insert = $conn->prepare("INSERT INTO tb_medico (funcionario_id) VALUES (?)");
		$insert->execute([$funcionario_id]);

		$medico_id = $conn->lastInsertId();

		$insert = $conn->prepare("INSERT INTO tb_medico_especialidade (medico_id, especialidade_id) VALUES (?, ?)");
		$insert->execute([$medico_id, $speciality_id]);

		$stmt_hour = $conn->prepare("INSERT INTO tb_horario (medico_id, data, hora_inicio, hora_fim) VALUES (?, ?, ?, ?)");
		$stmt_hour->execute([$medico_id, $data_consult, $hora_inicio, $hora_fim]);

		$conn->commit();

		echo json_encode([
				'success' => true,
				'message' => 'Médico cadastrado com sucesso!'
		]);

	} catch (Exception $e) {
		$conn->rollBack();
		echo json_encode([
				'success' => false,
				'message' => $e->getMessage()
		]);
	}
?>