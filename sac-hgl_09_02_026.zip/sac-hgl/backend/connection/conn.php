<?php
  $conn = new PDO("mysql:host=localhost;dbname=sac_hgl", "root", "");
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>