<?php

session_start();
header("Content-Type: application/json");

try{

$connect = new PDO("mysql:host=localhost;dbname=db_sac_hgl", "root", ""); 

 $email = $_POST['email'] ?? null;
    $password = $_POST['password' ] ?? null;
    
    $select = "SELECT id, name_user, email, conf_password, phone_number, data_nasc, gender FROM tb_us WHERE email = ? AND conf_password = ? LIMIT 1";

    $stmt = $connect->prepare($select);
    $stmt->execute([$email,$password]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
     
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
    

        echo json_encode([
            "status" => "ok",  "message" => "login realizado com sucesso"
            ]);
    } 
    else {
        echo json_encode(["message" => "Usuário ou senha incorretos", "status" => "error"]);
    }
} catch (error) {
    echo json_encode(["status" => "erro", "mensagem" => "erro no servidor", "Erro" => error]);
}

   

?>  