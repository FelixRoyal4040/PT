<?php

include '../backend/conexao_db.php';

$name = $_POST['name'] ??"";
$password = $_POST['password'] ??"";
$conf_password = $_POST['confirmPassword']??"";
$phone_number = $_POST['phone']??"";
$data_nasc = $_POST['data_nasc'] ??"";
$gender = $_POST['gender'] ??"";

if ($password ===  $conf_password){

    $sql = "INSERT INTO tb_us (name_user, email, conf_password, phone_number, data_nasc, gender) VALUES (?,?,?,?,?,?)";

    $send = $connect->prepare($sql);
    
    $stmt = $send->execute([$name, $email, $conf_password, $phone_number, $data_nasc, $gender]);

    if($stmt){
    echo json_encode("cadastro realizado com sucesso");
} else {
    echo json_encode("erro ao realizar cadastro");
}


}
else{
    echo("As palavras-passe colocadas não são iguais");
}