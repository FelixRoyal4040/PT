<?php

$connect = new pdo("mysql:host=localhost;db_name=db_sac_hgl", "root", "");

$connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);