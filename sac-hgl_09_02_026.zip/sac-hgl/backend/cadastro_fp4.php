<?php

$connect = new PDO("mysql:host=localhost;dbname=db_sac_hgl", "root", ""); 

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $conf_password = $_POST['confirm_password'];
    $phone_number = $_POST['phone'];
    $data_nasc = $_POST['data_nasc'];
    $gender = $_POST['gender'] ?? null;

    // Verificar se email já existe
$check = $connect->prepare("SELECT id FROM tb_us WHERE email = ?");
$check->execute([$email]);

if ($check->rowCount() > 0) {
    echo json_encode([
        "status" => "exist",
        "message" => "Este email já está cadastrado"
    ]);
    exit;
}

if($password !== $conf_password){
    echo json_encode([
        "status" => "error",
        "message" => "As senhas não coincidem."
    ]); 
    exit;
}

    $sql = "INSERT INTO tb_us (name_user, email, conf_password, phone_number, data_nasc, gender) VALUES (?,?,?,?,?,?)";

    $send = $connect->prepare($sql);
    
    $stmt = $send->execute([$name, $email, $conf_password, $phone_number, $data_nasc, $gender]);

    if($stmt){
        echo json_encode(["status" => "success", "message" => "Cadastro realizado com sucesso!"]);
    } else {
        echo "Erro ao realizar cadastro.";
    } 
    
    

?>


