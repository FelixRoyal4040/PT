<?php
  session_start();
  include_once 'backend/connection/conn.php';
  /*
 if (!isset($_SESSION['user_id'])) {
     header("Location: login.html");
     exit();
 } */
     $id = $_SESSION['user_id'] ?? 1;

     $sql = "
    SELECT p.nome_completo
    FROM tb_paciente p
    INNER JOIN tb_us u ON u.id = p.us_id
    WHERE u.id = :id_usuario
";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id_usuario', $id, PDO::PARAM_INT);
    $stmt->execute();
    $paciente = $stmt->fetch(PDO::FETCH_ASSOC);
    
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Painel do Paciente</title>
  <link rel="stylesheet" href="assets/css/painel.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/lucide/0.263.1/umd/lucide.min.js"></script>
</head>
<body>

  <div id="mainApp" class="">
    <div class="header">
      <div class="header-content">
        <div class="header-left">
          <div class="avatar" id="avatar">PA</div>
          <div>
            <h1 id="welcomeText" class="welcome-title">Olá, <span><?php echo htmlspecialchars($paciente['nome_completo'] ?? 'Usuário'); ?></span> </h1>
            <p class="welcome-subtitle">Bem-vindo ao seu painel de saúde</p>
          </div>
        </div>
        <div class="header-right">
          <div class="notification-btn">
            <i data-lucide="bell"></i>
            <span id="notificationBadge" class="notification-badge hidden">0</span>
          </div>
            <button class="logout-btn">
            <i data-lucide="log-out"></i>
            <a class="a" href="agendar_consulta.html">Agendar consulta</a>
          </button>

          <button class="logout-btn login_cadastro" id="btn_logout">
            <i data-lucide="log-out"></i>
            Sair 
          </button>
        </div>
      </div>
    </div>


    <div class="container">
      <div class="stats-grid">
        <div class="stat-card">
          <div>
            <p class="stat-label">Próxima Consulta</p>
            <p class="stat-value" id="nextAppointment">N/A</p>
          </div>
          <i data-lucide="calendar" class="stat-icon stat-icon-blue"></i>
        </div>
       
        <div class="stat-card">
          <div>
            <p class="stat-label">Total de consultas no ano</p>
            <p class="stat-value" id="medicationCount">0</p>
          </div>
          <i data-lucide="pill" class="stat-icon stat-icon-purple"></i>
        </div>
      </div>
      <div class="tabs">
        <div class="tabs-nav">
          <button class="tab-btn active" data-tab="overview" onclick="switchTab('overview')">
            <i data-lucide="activity"></i>
            <span>Visão Geral</span>
          </button>
          <button class="tab-btn" data-tab="appointments" onclick="switchTab('appointments')">
            <i data-lucide="calendar"></i>
            <span>Consultas</span>
          </button>
          <button class="tab-btn" data-tab="medications" onclick="switchTab('medications')">
            <i data-lucide="pill"></i>
            <span>Medicamentos</span>
          </button>
          <button class="tab-btn" data-tab="exams" onclick="switchTab('exams')">
            <i data-lucide="file-text"></i>
            <span>Exames</span>
          </button>
        </div>
      </div>


      <div class="content-grid">
        <div class="main-content">
          <div id="mainContent">
            <!-- Próximas Consultas -->
    <div class="card">
      <h2 class="card-title">
        <i data-lucide="calendar"></i>
        Próximas Consultas
      </h2>
    
          <div class="item-card">
            <div class="item-header">
              <div>
                <h3 class="item-title"></h3>
                <p class="item-subtitle"></p>
                <div class="item-info">
                  <i data-lucide="clock"></i>
                
                </div>
                <p style="font-size: 0.75rem; color: #9ca3af; margin-top: 0.25rem;"></p>
              </div>
              <span class="badge badge-green">Confirmado</span>
            </div>
          </div>
        <p class="empty-state">Você não tem consultas agendadas</p>
      
      <button class="btn-primary" style="margin-top: 1rem;" onclick="voltar()">Agendar Nova Consulta</button>
    </div>
          </div>
        </div>
        <div class="sidebar">
          <div id="sidebarContent">

           <div class="card">
      <h2 class="card-title">Minhas Consultas</h2>
      
      <!-- Próximas -->
      <h3 class="section-title">Próximas</h3>
    
          <div class="item-card">
            <div style="display: flex; justify-content: space-between; align-items: start;">
              <div>
                <h4 class="item-title"></h4>
                <p class="item-subtitle"></p>
                <p class="item-info" style="margin-top: 0.25rem;">
                 
                </p>
                <p style="font-size: 0.75rem; color: #9ca3af;"></p>
              </div>
              <div class="action-buttons">
                <button class="btn-link">Reagendar</button>
                <button class="btn-link danger" onclick="handleCancelAppointment('${apt.id}')">Cancelar</button>
              </div>
            </div>
          </div>
        
        <p class="empty-state" style="padding: 1rem;">Nenhuma consulta agendada</p>'
    
      <!-- Histórico -->
      <h3 class="section-title">Histórico</h3>
      
          <div class="item-card" style="background: #f9fafb;">
            <div style="display: flex; justify-content: space-between; align-items: start;">
              <div>
                <h4 class="item-title"></h4>
                <p class="item-subtitle"></p>
                <p class="item-info" style="margin-top: 0.25rem;">
                 
                </p>
              </div>
              <i data-lucide="check-circle" style="color: #16a34a; width: 20px; height: 20px;"></i>
            </div>
          </div>
         
        <p class="empty-state" style="padding: 1rem;">Nenhuma consulta no histórico</p>'
      
    </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
<script src="assets/js/painel.js"></script>
<script src="assets/js/logout.js"></script>
</html>